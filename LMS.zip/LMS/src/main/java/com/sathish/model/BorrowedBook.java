package com.sathish.model;

import java.time.LocalDate;

public class BorrowedBook
{
    private String userId;
    private String bookId;
    private String borrowDate;
    private String returnDate;
    private String lastReturnDate;
    private int fine;

    public BorrowedBook(String userId, String bookId, String borrowDate, String returnDate, String lastReturnDate, int fine) {
        this.userId = userId;
        this.bookId = bookId;
        this.borrowDate = borrowDate;
        this.returnDate = returnDate;
        this.lastReturnDate = lastReturnDate;
        this.fine = fine;
    }
    public BorrowedBook(String bookId, String borrowDate, String returnDate, String lastReturnDate, int fine) {
        this.bookId = bookId;
        this.borrowDate = borrowDate;
        this.lastReturnDate = lastReturnDate;
        this.returnDate = returnDate;
        this.fine = fine;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getBorrowDate() {
        return borrowDate;
    }

    public void setBorrowDate(String borrowDate) {
        this.borrowDate = borrowDate;
    }

    public String getLastReturnDate() {
        return lastReturnDate;
    }

    public void setLastReturnDate(String lastReturnDate) {
        this.lastReturnDate = lastReturnDate;
    }

    public int getFine() {
        return fine;
    }

    public void setFine(int fine) {
        this.fine = fine;
    }
}
