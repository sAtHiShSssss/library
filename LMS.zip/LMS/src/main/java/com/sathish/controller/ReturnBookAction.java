package com.sathish.controller;

import java.io.IOException;
import java.sql.SQLException;

import com.opensymphony.xwork2.Action;
import com.sathish.dao.UserService;

public class ReturnBookAction implements Action
{
    private String bookId;
    public void setBookId(String bookId) {
    	this.bookId = bookId;
    }
    public String getBookId() {
    	return bookId;
    }
    public void returnBook() throws SQLException, IOException
    {
    	new UserService().returnBook(bookId);
    }
    
    
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
}
