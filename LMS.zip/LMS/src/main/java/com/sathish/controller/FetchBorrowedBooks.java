package com.sathish.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.Action;
import com.sathish.dao.AdminService;

public class FetchBorrowedBooks implements Action
{

	public void borrowedBooks() throws IOException, SQLException
	{
		HttpServletResponse response = ServletActionContext.getResponse();
		PrintWriter out = response.getWriter();
		String jsonData = new AdminService().fetchBorrowedBooks();
		out.write(jsonData);;
	}
	
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
}
