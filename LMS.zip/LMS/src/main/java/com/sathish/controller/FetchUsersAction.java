package com.sathish.controller;

import com.opensymphony.xwork2.Action;
import com.sathish.dao.AdminService;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

public class FetchUsersAction implements Action
{
    public void fetchUsers() throws SQLException, IOException
    {
        String jsonData = new AdminService().fetchUsers();
        HttpServletResponse response = ServletActionContext.getResponse();
        PrintWriter out = response.getWriter();
        out.write(jsonData);
    }

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
}
