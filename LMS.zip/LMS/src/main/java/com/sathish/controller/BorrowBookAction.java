package com.sathish.controller;

import com.google.gson.Gson;
import com.opensymphony.xwork2.Action;
import com.sathish.dao.UserService;
import org.apache.struts2.ServletActionContext;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

public class BorrowBookAction implements Action
{
    private String bookId;
    public String getBookId(){
        return bookId;
    }
    public void setBookId(String bookId){
        this.bookId = bookId;
    }

    public void borrowBook() throws SQLException, IOException
    {
    	System.out.println("borrow");
        HttpServletRequest request = ServletActionContext.getRequest();
        HttpSession session = request.getSession();
        boolean membership = (boolean)session.getAttribute("membership");
        System.out.println(session.getAttribute("userId"));
        HttpServletResponse response = ServletActionContext.getResponse();
        PrintWriter out = response.getWriter();
        System.out.println(membership);
        Gson gson = new Gson();
        if(!membership)
        {
            out.write(gson.toJson("Not Member"));
            return;
        }

        boolean status = new UserService().borrowBook(this.bookId);
        if(status)
        {
            out.write(gson.toJson("success"));
        }
        else
        {
        	out.write(gson.toJson("error"));
        }
    }
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
}
