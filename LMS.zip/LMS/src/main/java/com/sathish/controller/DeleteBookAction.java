package com.sathish.controller;

import com.google.gson.Gson;
import com.opensymphony.xwork2.Action;
import com.sathish.dao.AdminService;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

public class DeleteBookAction implements Action
{
    private String bookId;
    public void setBookId(String bookId){
        this.bookId = bookId;
    }
    public String getBookId(){
        return bookId;
    }
    
    public void deleteBook() throws SQLException, IOException
    {
    	System.out.println(this.bookId);
    	Gson gson = new Gson();
    	HttpServletResponse response = ServletActionContext.getResponse();
    	PrintWriter out = response.getWriter();
    	String json = "";
    	boolean status = new AdminService().deleteBook(this.bookId);
    	if(status)
    	{
    		json = gson.toJson("deletebooksuccess");
    		out.write(json);
    	}
    	else
    	{
    		json = gson.toJson("deletebookerror");
    		out.write(json);
    	}
    }
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
    
}
