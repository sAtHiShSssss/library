package com.sathish.controller;

import java.io.IOException;
import java.sql.SQLException;

import com.opensymphony.xwork2.Action;
import com.sathish.dao.UserService;

public class GetUserDetails implements Action
{

	public void fetchUserDetails() throws SQLException, IOException
	{
		new UserService().getUserDetails();
	}
	
	
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
}
