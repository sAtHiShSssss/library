package com.sathish.controller;

import com.opensymphony.xwork2.Action;

public class UpdateBookAction implements Action
{

    public String execute()
    {
        return "";
    }
}
